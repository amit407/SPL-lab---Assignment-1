#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv){
  int debug_flag = 0;
  int plus_flag = 0;
  int minus_flag = 0;
  int digits[100];
  int d_ind = 0;
  int i_flag = 0;
  int o_flag = 0;
  FILE *input_file=stdin;
  FILE* output_file=stdout;
  char* input_file_name;
  char* output_file_name;
  int i;
  for(i = 1; i < argc; i++){
    if(strstr(argv[i],"-e") != NULL || strstr(argv[i],"+e") != NULL ){      //found -e or +e 
      for(int ind = 2; ind < strlen(argv[i]); ind++){
        if(('0' <= argv[i][ind]) && (argv[i][ind]) <= '9'){ 
          digits[d_ind] = argv[i][ind] - '0';           //saving the flag's digits
          d_ind++;
        }
      }
      if (strstr(argv[i],"-e") != NULL){   // found -e
        minus_flag = 1;
      }
      else{
        plus_flag = 1;
      }
    }
    if(strstr(argv[i],"-i") != NULL){    //found -i
      input_file_name = argv[i]+2;
      i_flag = 1;
    }
    if(strcmp(argv[i],"-D") == 0){        //found -D
	    fprintf(stderr,"-D\n");
      debug_flag = 1;
    }
    if(strstr(argv[i],"-o") != NULL){       //found -o
      output_file_name = argv[i]+2;
      o_flag=1;
    }
  }
  if(i_flag){
    input_file = fopen(input_file_name,"r");
    if(input_file == NULL){
      fprintf(stderr, "cannot open the input file\n");
      return 0;}
  }
  if(o_flag){
    output_file = fopen(output_file_name,"w+");
    if(output_file == NULL){
      fprintf(stderr, "cannot open the output file\n");
      return 0;}
  }
  char given_char;
  int index = 0;
  if(minus_flag == 1 || plus_flag == 1 ){         //e flag
    given_char = fgetc(input_file);
    while(given_char != EOF){
      if(minus_flag){
        fprintf(output_file,"%c",given_char - digits[index]); 
      }
      else{
        fprintf(output_file,"%c",given_char + digits[index]);
      }
      index++;
      if(index == d_ind || given_char == 10){ 
        index = 0;
      }
      given_char = fgetc(input_file);
    }
  }
  else{                         //no e flag
    int j=0;
    char out_buf[100];
    given_char = fgetc(input_file);
    while(given_char != EOF){ 
      if(given_char==10){   
        out_buf[j]='\0';    
        fprintf(output_file,"%s\n",out_buf);
        for(int k=0;k<j;k++){
          out_buf[k]=' ';
        }
        j=0;
      }
      if('a'<=given_char && given_char <= 'z'){
        out_buf[j]=(given_char-32); 
        if(debug_flag)             
          fprintf(stderr,"%x %x\n",given_char,given_char-32);
      }
      else
      {
        out_buf[j]=given_char;
        if(debug_flag)
          fprintf(stderr, "%x %x\n",given_char,given_char);
      }
      j++;
      given_char = fgetc(input_file); 
    }
  }
}

