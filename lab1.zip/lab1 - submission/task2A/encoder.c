#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv){
  int digits[100];
  int d_ind = 0;
  int index = 0;
  int i_flag = 0;
  FILE* file = stdin;
  char* file_name;
  int debug_flag = 0;
  int plus_flag = 0;
  int minus_flag = 0;
  int i;
  for(i=1;i<argc;i++){      
    if(strstr(argv[i],"-e") != NULL || strstr(argv[i],"+e") != NULL ){      //found -e or +e 
      for(int ind = 2; ind < strlen(argv[i]); ind++){
        if(('0' <= argv[i][ind]) && (argv[i][ind]) <= '9'){ 
          digits[d_ind] = argv[i][ind] - '0';           //saving the flag's digits
          d_ind++;
        }
      }
      if (strstr(argv[i],"-e") != NULL){   // found -e
        minus_flag = 1;
      }
      else{
        plus_flag = 1;
      }
    }
    if(strstr(argv[i],"-i") != NULL){    //found -i
      file_name = argv[i]+2;
      i_flag = 1;
    }
    if(strcmp(argv[i],"-D") == 0){        //found -D
	    fprintf(stderr,"-D\n");
      debug_flag=1;
    }
  }
  char given_char;
  int j = 0;
  if(i_flag){         //input from a file
    file = fopen(file_name,"r");
    if(file == NULL){
      fprintf(stderr, "cannot open file\n");
      return 0;
    }
  }
  if(minus_flag == 1 || plus_flag == 1 ){       //e flag
    given_char = fgetc(file);
    while(given_char != EOF){
      if(minus_flag){
        printf("%c",given_char - digits[index]);  
      }
      else{
        printf("%c",given_char + digits[index]);
      }
      index++;
      if(index == d_ind || given_char == 10){ 
        index = 0;
      }  
      given_char = fgetc(file);
    }
  }
  else{                       //no e flag
    fseek(file, 0, SEEK_END);
    int sz = ftell(file);
    fseek(file, 0, SEEK_SET);
    char out_buf[sz];
    given_char = fgetc(file);        
    while(given_char != EOF){      
      if(given_char==10){          
        out_buf[j]='\0';        
        printf("%s\n",out_buf);
      }
      if('a'<=given_char && given_char <= 'z'){
        out_buf[j]=(given_char-32);
        if(debug_flag)            
          fprintf(stderr,"%x %x\n",given_char,given_char-32);
      }
      else
      {
        out_buf[j]=given_char;
        if(debug_flag)
          fprintf(stderr, "%x %x\n",given_char,given_char);
      }
      j++;
      given_char = fgetc(file);
    }
  }
  return 0;
}