#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv){
  int digits[100];
  int d_ind = 0;
  int plus_flag = 0;
  int minus_flag = 0;
  for(int i = 1 ; i < argc ; i++){      
    if(strstr(argv[i],"-e") != NULL || strstr(argv[i],"+e") != NULL ){      //found -e or +e 
      for(int ind = 2; ind < strlen(argv[i]); ind++){
        if(('0' <= argv[i][ind]) && (argv[i][ind]) <= '9'){ 
          digits[d_ind] = argv[i][ind] - '0';           //saving the flag's digits
          d_ind++;
        }
      }
      if (strstr(argv[i],"-e") != NULL){   // found -e
        minus_flag = 1;
      }
      else{
        plus_flag = 1;
      }
    }
  }               // end of reading the e flag
  int index = 0;
  char given_char;
  if(plus_flag == 1 || minus_flag == 1 ){       //there is e flag
    given_char = getchar();      
    while(given_char != EOF){
      if(minus_flag){
        printf("%c",given_char - digits[index]);
      }
      else{
        printf("%c",given_char + digits[index]);
      }
      index++;
      if(index == d_ind){ 
        index = 0;
      }
      if (given_char == 10){
        index = 0;
        printf("\n");
      }
      given_char=getchar(); 
    }
  }
  else{               // no e flag
    given_char = getchar();  
    while(given_char != EOF){
      if('a' <= given_char && given_char <= 'z'){
        printf("%c" , given_char - 32);
      }
      else{
        printf("%c" , given_char);
      }
      given_char = getchar();
    }
  }
  return 0;
}

